# Licenza d’Uso – MindMeld (Tutti i Diritti Riservati)

Copyright © 2025 [TUO NOME]

Questo software, incluso ma non limitato a codice sorgente, design, interfaccia utente, logica e contenuti testuali, è protetto da copyright.

**Tutti i diritti sono riservati.**

Non è consentito:

- Copiare, modificare, redistribuire o creare opere derivate da questo codice
- Usarlo per scopi commerciali senza autorizzazione scritta
- Pubblicarlo, venderlo o incorporarlo in altri software o prodotti digitali

Qualsiasi uso non autorizzato sarà perseguito ai sensi di legge.

Per licenze commerciali, collaborazione o partnership:
📧 Contattami a: [la-tua-email@example.com]
